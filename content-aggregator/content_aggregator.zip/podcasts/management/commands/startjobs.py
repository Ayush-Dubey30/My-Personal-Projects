# Standard Library
import logging

# Django
from django.conf import settings
from django.core.management.base import BaseCommand

# Third Party
import feedparser
from dateutil import parser
from apscheduler.schedulers.blocking import BlockingScheduler
from apscheduler.triggers.cron import CronTrigger
from django_apscheduler.jobstores import DjangoJobStore
from django_apscheduler.models import DjangoJobExecution

# Models
from podcasts.models import Episode

logger = logging.getLogger(__name__)

def save_new_episodes(feed):
    """Saves new episodes to the database.

    Checks the episode GUID against the episodes currently stored in the
    database. If not found, then a new `Episode` is added to the database.

    Args:
        feed: requires a feedparser object
    """
    podcast_title = feed.channel.title
    podcast_image = feed.channel.image["href"]
    podcast_description = feed.channel.description

    for item in feed.entries:
        if not Episode.objects.filter(guid=item.guid).exists():
            episode = Episode(
                title=item.title,
                pub_date=parser.parse(item.published),
                description=podcast_description,
                link=item.link,
                image=podcast_image,
                podcast_name=podcast_title,
                guid=item.guid,
            )
            episode.save()

def fetch_hdtgm_episodes():
    """Fetches new episodes from RSS for How Did This Get Made? Podcast"""
    _feed = feedparser.parse("https://feeds.simplecast.com/Ao0C24M8")
    save_new_episodes(_feed)

def fetch_bbcearth_episodes():
    """Fetches new episodes from RSS for the BBC Earth Podcast."""
    _feed = feedparser.parse("https://podcasts.files.bbci.co.uk/b015sqc7.rss")
    save_new_episodes(_feed)

def fetch_scriptnotes_episodes():
    """Fetches new episodes from RSS for the Scriptnotes Podcast."""
    _feed = feedparser.parse("https://scriptnotes.libsyn.com/rss")
    save_new_episodes(_feed)

def fetch_startalk_episodes():
    """Fetches new episodes from RSS for the StarTalk Podcast."""
    _feed = feedparser.parse("https://feeds.simplecast.com/4T39_jAj")
    save_new_episodes(_feed)

def fetch_aoc_episodes():
    """Fetches new episodes from RSS for the Anime Out of Context Podcast."""
    _feed = feedparser.parse("https://feed.podbean.com/animeoutofcontext/feed.xml")
    save_new_episodes(_feed)

def delete_old_job_executions(max_age=604_800):
    """Deletes all apscheduler job execution logs older than `max_age`."""
    DjangoJobExecution.objects.delete_old_job_executions(max_age)

class Command(BaseCommand):
    def handle(self, *args, **options):
        scheduler = BlockingScheduler(timezone=settings.TIME_ZONE)
        scheduler.add_jobstore(DjangoJobStore(), "default")

        scheduler.add_job(
            fetch_hdtgm_episodes,
            trigger="interval",
            minutes=2,
            id="How Did This Get Made?",
            max_instances=1,
            replace_existing=True,
        )
        logger.info("Added job: How Did This Get Made?")
        
        scheduler.add_job(
            fetch_bbcearth_episodes,
            trigger="interval",
            minutes=2,
            id="BBC Earth",
            max_instances=1,
            replace_existing=True,
        )
        logger.info("Added job: BBC Earth")

        scheduler.add_job(
            fetch_scriptnotes_episodes,
            trigger="interval",
            minutes=2,
            id="Scriptnotes",
            max_instances=1,
            replace_existing=True,
        )
        logger.info("Added job: Scriptnotes")

        scheduler.add_job(
            fetch_startalk_episodes,
            trigger="interval",
            minutes=2,
            id="StarTalk",
            max_instances=1,
            replace_existing=True,
        )
        logger.info("Added job: StarTalk")

        scheduler.add_job(
            fetch_aoc_episodes,
            trigger="interval",
            minutes=2,
            id="Anime Out Of Context",
            max_instances=1,
            replace_existing=True,
        )
        logger.info("Added job: Anime Out of Context")

        scheduler.add_job(
            delete_old_job_executions,
            trigger=CronTrigger(
                day_of_week="mon", hour="00", minute="00"
            ),  # Midnight on Monday, before start of the next work week.
            id="Delete Old Job Executions",
            max_instances=1,
            replace_existing=True,
        )
        logger.info("Added weekly job: Delete Old Job Executions.")

        try:
            logger.info("Starting scheduler...")
            scheduler.start()
        except KeyboardInterrupt:
            logger.info("Stopping scheduler...")
            scheduler.shutdown()
            logger.info("Scheduler shut down successfully!")